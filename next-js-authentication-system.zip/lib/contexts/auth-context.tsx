"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { User, Membership } from "@/lib/types/auth"
import { useRouter } from "next/navigation"

interface AuthContextType {
  user: User | null
  membership: Membership | null
  isLoading: boolean
  login: (credentials: any) => Promise<void>
  logout: () => void
  refreshSession: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [membership, setMembership] = useState<Membership | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Check for existing session on mount
    const checkSession = async () => {
      try {
        console.log("[v0] Checking session...")
        // For now, we simulate a loading state
        setIsLoading(false)
      } catch (error) {
        console.error("[v0] Session check failed:", error)
        setIsLoading(false)
      }
    }
    checkSession()
  }, [])

  const login = async (credentials: any) => {
    setIsLoading(true)
    try {
      console.log("[v0] Attempting login...")
      // Simulate successful response with memberships
      const mockUser: User = { id: "1", email: credentials.email, name: "Admin User" }
      setUser(mockUser)
      setIsLoading(false)
      router.push("/")
    } catch (error) {
      setIsLoading(false)
      throw error
    }
  }

  const logout = () => {
    setUser(null)
    setMembership(null)
    router.push("/login")
  }

  const refreshSession = async () => {
    // Logic to refresh user and membership data from backend
  }

  return (
    <AuthContext.Provider value={{ user, membership, isLoading, login, logout, refreshSession }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
