export const apiClient = {
  get: async (url: string) => {
    // ... logic ...
  },
  post: async (url: string, data: any) => {
    // ... logic ...
  },
}
