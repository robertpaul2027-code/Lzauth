"use client"

import { useAuth } from "@/lib/contexts/auth-context"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Button } from "@/components/ui/button"

export default function ManagerDashboard() {
  const { user, memberships, logout } = useAuth()
  const currentRestaurant = memberships[0]?.restaurant

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen flex-col items-center justify-center bg-background space-y-6">
        <div className="text-center">
          <h1 className="text-4xl font-bold">Manager Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Welcome back, {user?.name} at {currentRestaurant?.name}
          </p>
        </div>
        <Button
          onClick={logout}
          variant="outline"
          className="border-gold text-gold hover:bg-gold hover:text-black bg-transparent"
        >
          Logout
        </Button>
      </div>
    </ProtectedRoute>
  )
}
