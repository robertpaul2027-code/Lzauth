export default function proxy(request) {
  const url = new URL(request.url)

  // Logic for protected routes would go here
  // For now, this is a placeholder as actual auth depends on backend

  return null
}
