"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/contexts/auth-context"

export default function RootPage() {
  const { user, membership, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.push("/login")
      } else if (!membership) {
        router.push("/restaurant/create")
      } else {
        const role = membership.role.toLowerCase()
        router.push(`/dashboard/${role}`)
      }
    }
  }, [user, membership, isLoading, router])

  return (
    <div className="flex min-h-screen items-center justify-center bg-black">
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-[oklch(0.85_0.15_85)] border-t-transparent" />
    </div>
  )
}
