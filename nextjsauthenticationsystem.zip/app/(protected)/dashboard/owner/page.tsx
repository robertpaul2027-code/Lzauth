"use client"

import { useAuth } from "@/lib/contexts/auth-context"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LayoutDashboard, Store, Users, Settings, LogOut } from "lucide-react"

export default function OwnerDashboard() {
  const { user, memberships, logout } = useAuth()
  const currentRestaurant = memberships[0]?.restaurant

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen bg-background">
        {/* Simple Sidebar */}
        <aside className="w-64 border-r border-border/50 bg-card p-6 flex flex-col space-y-8">
          <div className="flex items-center space-x-2 px-2">
            <div className="h-8 w-8 rounded bg-gold" />
            <span className="text-xl font-bold tracking-tight">Resto OS</span>
          </div>

          <nav className="flex-1 space-y-1">
            <Button variant="secondary" className="w-full justify-start bg-gold/10 text-gold hover:bg-gold/20">
              <LayoutDashboard className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="w-full justify-start text-muted-foreground">
              <Store className="mr-2 h-4 w-4" />
              Restaurant
            </Button>
            <Button variant="ghost" className="w-full justify-start text-muted-foreground">
              <Users className="mr-2 h-4 w-4" />
              Staff
            </Button>
            <Button variant="ghost" className="w-full justify-start text-muted-foreground">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </nav>

          <Button
            variant="ghost"
            onClick={logout}
            className="w-full justify-start text-destructive hover:bg-destructive/10"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8 space-y-8">
          <header className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Welcome, {user?.name}</h1>
              <p className="text-muted-foreground">Managing {currentRestaurant?.name}</p>
            </div>
            <div className="px-3 py-1 bg-gold/20 text-gold rounded-full text-xs font-bold tracking-widest uppercase">
              Owner
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">Daily Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$0.00</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Staff</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">Active Tables</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">0</div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
