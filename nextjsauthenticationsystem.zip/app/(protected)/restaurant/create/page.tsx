"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/contexts/auth-context"
import { restaurantApi } from "@/lib/api/restaurant"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useRouter } from "next/navigation"
import { ProtectedRoute } from "@/components/auth/protected-route"

export default function CreateRestaurantPage() {
  const [name, setName] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { session, logout } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session?.token) return

    setIsLoading(true)
    setError(null)

    try {
      await restaurantApi.create(name, session.token)
      // Redirect to owner dashboard after successful creation
      router.push("/dashboard/owner")
    } catch (err: any) {
      setError(err.message || "Failed to create restaurant")
      console.error("[v0] Create restaurant failed:", err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="w-full max-w-md">
          <Card className="border-border/50 bg-card shadow-xl">
            <form onSubmit={handleSubmit}>
              <CardHeader>
                <CardTitle className="text-2xl font-bold">Create Restaurant</CardTitle>
                <CardDescription>
                  {"You don't have any restaurant memberships yet. Create your first restaurant to get started."}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive" className="bg-destructive/10 text-destructive border-destructive/20">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <div className="space-y-2">
                  <Label htmlFor="name">Restaurant Name</Label>
                  <Input
                    id="name"
                    placeholder="The Golden Spoon"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-background focus-visible:ring-gold"
                  />
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4">
                <Button
                  type="submit"
                  className="w-full bg-gold text-black hover:bg-gold/90 font-semibold py-6 text-lg"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-black border-t-transparent" />
                  ) : (
                    "Create Restaurant"
                  )}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={logout}
                  className="w-full text-muted-foreground hover:text-foreground"
                >
                  Logout
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
