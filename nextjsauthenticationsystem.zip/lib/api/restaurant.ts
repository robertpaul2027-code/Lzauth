import { apiClient } from "./client"
import type { Membership } from "@/lib/types/auth"

export const restaurantApi = {
  create: async (name: string, token: string): Promise<Membership> => {
    return apiClient.post<Membership>("/restaurants", { name }, token)
  },

  getMemberships: async (token: string): Promise<Membership[]> => {
    return apiClient.get<Membership[]>("/memberships", token)
  },
}
