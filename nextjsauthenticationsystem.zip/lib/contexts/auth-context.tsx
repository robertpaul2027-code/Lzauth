"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { User, Membership } from "@/lib/types/auth"

interface AuthContextType {
  user: User | null
  membership: Membership | null
  isLoading: boolean
  error: string | null
  login: (credentials: any) => Promise<void>
  logout: () => void
  refreshSession: () => Promise<void>
  clearError: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [membership, setMembership] = useState<Membership | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkSession = async () => {
      try {
        console.log("[v0] Checking session...")
        // TODO: Replace with actual API call to check if user has active session
        // const response = await fetch('/api/auth/me');
        // if (response.ok) {
        //   const data = await response.json();
        //   setUser(data.user);
        //   setMembership(data.membership);
        // }

        // For now, check localStorage or cookies for session
        const savedUser = localStorage.getItem("user")
        const savedMembership = localStorage.getItem("membership")

        if (savedUser && savedMembership) {
          setUser(JSON.parse(savedUser))
          setMembership(JSON.parse(savedMembership))
        }

        setIsLoading(false)
      } catch (error) {
        console.error("[v0] Session check failed:", error)
        setIsLoading(false)
      }
    }

    checkSession()
  }, [])

  const login = async (credentials: any) => {
    setIsLoading(true)
    setError(null)
    try {
      console.log("[v0] Attempting login...")
      // TODO: Replace with actual API call to your backend
      // const response = await fetch('/api/auth/login', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(credentials),
      // });
      // if (!response.ok) throw new Error('Login failed');
      // const data = await response.json();

      // Simulate successful response with memberships
      const mockUser: User = { id: "1", email: credentials.email, name: "Admin User" }
      const mockMembership: Membership = { id: "1", userId: "1", restaurantId: "1", role: "owner" }

      setUser(mockUser)
      setMembership(mockMembership)

      // Save to localStorage for persistence
      localStorage.setItem("user", JSON.stringify(mockUser))
      localStorage.setItem("membership", JSON.stringify(mockMembership))

      setIsLoading(false)
    } catch (err) {
      setIsLoading(false)
      const errorMessage = err instanceof Error ? err.message : "Login failed"
      setError(errorMessage)
      throw err
    }
  }

  const logout = () => {
    setUser(null)
    setMembership(null)
    setError(null)
    localStorage.removeItem("user")
    localStorage.removeItem("membership")
  }

  const refreshSession = async () => {
    // Logic to refresh user and membership data from backend
  }

  const clearError = () => {
    setError(null)
  }

  return (
    <AuthContext.Provider value={{ user, membership, isLoading, error, login, logout, refreshSession, clearError }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
