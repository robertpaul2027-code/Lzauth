export type UserRole = "OWNER" | "MANAGER" | "STAFF"

export interface User {
  id: string
  email: string
  name?: string
}

export interface Restaurant {
  id: string
  name: string
  owner_id: string
}

export interface Membership {
  id: string
  user_id: string
  restaurant_id: string
  role: UserRole
}

export interface AuthState {
  user: User | null
  membership: Membership | null
  restaurant: Restaurant | null
  isLoading: boolean
}
