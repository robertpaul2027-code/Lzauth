"use client"

import { create } from "zustand"
import type { AuthState, User, Membership, Restaurant } from "@/lib/auth-types"

interface AuthStore extends AuthState {
  setAuth: (user: User | null, membership: Membership | null, restaurant: Restaurant | null) => void
  logout: () => void
}

export const useAuth = create<AuthStore>((set) => ({
  user: null,
  membership: null,
  restaurant: null,
  isLoading: true,
  setAuth: (user, membership, restaurant) => set({ user, membership, restaurant, isLoading: false }),
  logout: () => set({ user: null, membership: null, restaurant: null, isLoading: false }),
}))
